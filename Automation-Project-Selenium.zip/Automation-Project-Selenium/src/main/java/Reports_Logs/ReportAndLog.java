package Reports_Logs;
import org.apache.logging.log4j.*;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.*;
import org.apache.logging.log4j.core.config.properties.*;
import org.apache.logging.log4j.core.config.xml.*;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
public class ReportAndLog {

	
	public static final Logger Log = LogManager.getLogger(ReportAndLog.class);
	ExtentReports Extent_Report;
	ExtentTest Extent_Log;
	
	
	
   protected static void SetLog(String Message)
   {
	   
	
	

	   
}
   public void Generate_Html_Report()
   {
   
   }
   public void Generate_Doc_Report()
   {
   
}
   public void Generate_Excel_Report()
   {
	   
   }
}